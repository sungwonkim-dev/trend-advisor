from django.apps import AppConfig


class BusinesstimingConfig(AppConfig):
    name = 'businesstiming'
